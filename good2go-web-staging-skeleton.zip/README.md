# Good2Go Web Staging

Basic Next.js staging skeleton.