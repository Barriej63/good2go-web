export default function Page() {
  return (
    <main style={{display:'flex',height:'100vh',justifyContent:'center',alignItems:'center'}}>
      <h1>✅ Good2Go Staging Placeholder</h1>
    </main>
  )
}
