import { NextRequest, NextResponse } from "next/server";
import axios from "axios";
import nodemailer from "nodemailer";
import { adminDb } from "@/src/firebaseAdmin";

export const dynamic = "force-dynamic";

function getPaymarkAuth() {
  const username = process.env.WORLDLINE_USERNAME || process.env.PAYMARK_CLIENT_ID;
  const password = process.env.WORLDLINE_PASSWORD || process.env.PAYMARK_API_KEY;
  const env = process.env.WORLDLINE_ENV || process.env.PAYMARK_ENV || "uat";
  return { username, password, env };
}

async function verifyTransaction(transactionId: string) {
  const { username, password, env } = getPaymarkAuth();
  const base = env === "prod"
    ? "https://secure.paymarkclick.co.nz/api/webpayments/paymentservice/rest"
    : "https://uat.paymarkclick.co.nz/api/webpayments/paymentservice/rest";
  const url = `${base}/?cmd=_xclick&transaction_id=${encodeURIComponent(transactionId)}`;
  const auth = Buffer.from(`${username}:${password}`).toString("base64");
  const res = await axios.get(url, { headers: { "Authorization": `Basic ${auth}` } });
  const text: string = typeof res.data === "string" ? res.data : String(res.data);
  return text;
}

async function sendEmail(to: string, subject: string, html: string) {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.FROM_EMAIL) return;
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  await transporter.sendMail({ from: process.env.FROM_EMAIL, to, subject, html });
}

export async function POST(req: NextRequest) {
  const form = await req.formData();
  const TransactionId = String(form.get("TransactionId") || "");
  const Reference = String(form.get("Reference") || "");
  const Particular = String(form.get("Particular") || "");
  const Email = String(form.get("Email") || "");
  const CardHolder = String(form.get("CardHolder") || "");

  if (!TransactionId) return NextResponse.json({ error: "Missing TransactionId" }, { status: 400 });

  const verification = await verifyTransaction(TransactionId);
  const ok = /<status>1<\/status>|Status>1</i.test(verification) || /SUCCESS/i.test(verification);

  let bookingId: string | null = null;
  try {
    const p = JSON.parse(Particular);
    bookingId = p.bookingId || null;
  } catch {}

  if (ok && bookingId) {
    await adminDb.collection("bookings").doc(bookingId).update({ status: "paid", transactionId: TransactionId, reference: Reference });
    if (Email) {
      await sendEmail(
        Email,
        "Good2Go booking confirmed",
        `<p>Thanks ${CardHolder ? CardHolder : ""}! Your payment has been received.</p><p>Transaction: ${TransactionId}</p><p>Reference: ${Reference}</p>`
      );
    }
    return NextResponse.redirect(new URL("/success", req.url));
  } else {
    if (bookingId) await adminDb.collection("bookings").doc(bookingId).update({ status: "cancelled" });
    return NextResponse.redirect(new URL("/cancel", req.url));
  }
}
