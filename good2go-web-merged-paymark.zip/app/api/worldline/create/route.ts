import { NextRequest, NextResponse } from "next/server";
import axios from "axios";
import { z } from "zod";
import { adminDb } from "@/src/firebaseAdmin";

const schema = z.object({
  region: z.string(),
  slot: z.object({
    weekday: z.string(),
    start: z.string(),
    end: z.string(),
    venueAddress: z.string().optional(),
    note: z.string().optional()
  }),
  name: z.string(),
  email: z.string().email(),
});

function getPaymarkConfig() {
  const username = process.env.WORLDLINE_USERNAME || process.env.PAYMARK_CLIENT_ID;
  const password = process.env.WORLDLINE_PASSWORD || process.env.PAYMARK_API_KEY;
  const accountId = process.env.WORLDLINE_ACCOUNT_ID || process.env.PAYMARK_ACCOUNT_ID;
  const env = process.env.WORLDLINE_ENV || process.env.PAYMARK_ENV || "uat";
  const referencePrefix = process.env.G2G_REFERENCE_PREFIX || process.env.BOOKING_REF_PREFIX || "G2G";
  const returnUrl = process.env.WORLDLINE_RETURN_URL;
  return { username, password, accountId, env, referencePrefix, returnUrl };
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.message }, { status: 400 });

  const amountNZD = parseFloat(process.env.G2G_BOOKING_FEE_NZD || "0");
  if (!amountNZD || amountNZD <= 0) return NextResponse.json({ error: "Booking fee amount not configured." }, { status: 500 });

  const { username, password, accountId, env, referencePrefix, returnUrl } = getPaymarkConfig();
  if (!username || !password || !accountId || !returnUrl) {
    return NextResponse.json({ error: "Worldline/Paymark env not fully configured." }, { status: 500 });
  }

  const pendingRef = await adminDb.collection("bookings").add({
    region: parsed.data.region,
    slot: parsed.data.slot,
    name: parsed.data.name,
    email: parsed.data.email,
    status: "pending",
    amount: Math.round(amountNZD * 100),
    createdAt: new Date(),
  });

  const endpoint = env === "prod"
    ? "https://secure.paymarkclick.co.nz/api/webpayments/paymentservice/rest/WPRequest"
    : "https://uat.paymarkclick.co.nz/api/webpayments/paymentservice/rest/WPRequest";

  const form = new URLSearchParams();
  form.set("username", username);
  form.set("password", password);
  form.set("account_id", accountId);
  form.set("cmd", "_xclick");
  form.set("amount", amountNZD.toFixed(2));
  form.set("type", "purchase");
  form.set("reference", `${referencePrefix}-${pendingRef.id[:8]}`);
  form.set("particular", JSON.stringify({ bookingId: pendingRef.id, region: parsed.data.region }));
  form.set("return_url", returnUrl);

  try {
    const res = await axios.post(endpoint, form.toString(), {
      headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/xml" },
      timeout: 120000,
    });
    const text: string = typeof res.data === "string" ? res.data : String(res.data);
    const match = text.match(/https?:[^<\s]+/i);
    if (!match) throw new Error("Failed to parse Hosted Payment Page URL");
    const redirectUrl = match[0];
    return NextResponse.json({ redirectUrl });
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "Worldline request failed" }, { status: 500 });
  }
}
