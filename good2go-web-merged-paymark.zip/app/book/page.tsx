'use client';
import { useEffect, useState } from 'react';
import { db } from '@/src/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { z } from 'zod';

const REGIONS = ['Auckland', 'Waikato', 'Bay of Plenty'];

const FormSchema = z.object({
  region: z.string().min(1),
  slot: z.string().min(1), // JSON string
  name: z.string().min(2),
  email: z.string().email(),
});

export default function BookPage() {
  const [region, setRegion] = useState('Waikato');
  const [slots, setSlots] = useState<{label:string,value:string}[]>([]);
  const [slot, setSlot] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      setError(null);
      const ref = doc(db, 'config', `timeslots_${region}`);
      const snap = await getDoc(ref);
      const data = snap.exists() ? snap.data() as any : { slots: [] };
      setSlots((data.slots || []).map((s:any) => ({ label: `${s.weekday} ${s.start}-${s.end} @ ${s.venueAddress || 'TBC'}`, value: JSON.stringify(s) })));
    }
    load();
  }, [region]);

  async function submit() {
    setError(null);
    const parsed = FormSchema.safeParse({ region, slot, name, email });
    if (!parsed.success) {
      setError(parsed.error.errors[0]?.message || 'Check the form.');
      return;
    }
    try {
      setLoading(true);
      const res = await fetch('/api/worldline/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          region, 
          slot: JSON.parse(slot), 
          name, 
          email 
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      const { redirectUrl } = await res.json();
      window.location.href = redirectUrl;
    } catch (e:any) {
      setError(e.message || 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <section>
      <h2>Book a Session</h2>
      <label>Region<br/>
        <select value={region} onChange={e=>setRegion(e.target.value)}>
          {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
        </select>
      </label>
      <br/>
      <label>Time Slot<br/>
        <select value={slot} onChange={e=>setSlot(e.target.value)}>
          <option value="">Select…</option>
          {slots.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
      </label>
      <br/>
      <label>Full Name<br/>
        <input value={name} onChange={e=>setName(e.target.value)} />
      </label>
      <br/>
      <label>Email<br/>
        <input type="email" value={email} onChange={e=>setEmail(e.target.value)} />
      </label>
      <br/>
      {error && <p style={{color:'#b00'}}>{error}</p>}
      <button onClick={submit} disabled={loading}>{loading ? 'Processing…' : 'Proceed to Payment'}</button>
      <p style={{marginTop:16, color:'#777'}}>You will be redirected to a secure Worldline (Paymark Click) payment page.</p>
    </section>
  );
}
