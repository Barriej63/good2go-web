# Good2Go Web (Bookings + Paymark/Worldline HPP)

This version is aligned to your Vercel env names.

## Env name mapping
- `PAYMARK_CLIENT_ID` → used as Worldline username
- `PAYMARK_API_KEY` → used as Worldline password
- `PAYMARK_ACCOUNT_ID` → Worldline account_id
- `PAYMARK_ENV` → `uat` or `prod`
- `BOOKING_REF_PREFIX` → booking reference prefix (fallback to `G2G_REFERENCE_PREFIX` if present)
- `WORLDLINE_RETURN_URL` → absolute https URL to `/api/worldline/return`

Firebase Admin (server routes):
- `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`

Public Firebase:
- all `NEXT_PUBLIC_FIREBASE_*`

## Flow
`/book` → `/api/worldline/create` (creates pending booking via Admin SDK) → HPP redirect → Worldline POST → `/api/worldline/return` verifies + marks `paid` + emails → `/success`.

## Admin
`/admin` lists bookings (add auth before production).
