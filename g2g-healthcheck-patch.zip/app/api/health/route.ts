export const dynamic = "force-dynamic";
export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { adminDb } from "@/src/firebaseAdmin";

export async function GET() {
  try {
    // simple read to validate admin credentials
    const snap = await adminDb.collection("products").limit(1).get();
    return NextResponse.json({ ok: true, count: snap.size });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || String(e) }, { status: 500 });
  }
}
