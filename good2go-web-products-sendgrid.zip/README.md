# Good2Go Web (Products + Paymark HPP + SendGrid email)

## What this includes
- Firestore `products` (add/edit to grow catalog)
- Worldline/Paymark HPP payments (amount set by product)
- SendGrid email confirmations (fallback to SMTP)
- Weekday-based time slots under `config/timeslots_<Region>`

## Env (.env.local or Vercel)
Public Firebase:
- NEXT_PUBLIC_FIREBASE_*

Server:
- FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY
- PAYMARK_ENV, PAYMARK_CLIENT_ID, PAYMARK_API_KEY, PAYMARK_ACCOUNT_ID
- WORLDLINE_RETURN_URL=https://YOUR_DOMAIN/api/worldline/return (or leave unset to auto-infer origin)

Email:
- SENDGRID_API_KEY
- SENDGRID_FROM="Good2Go <help@good2go-rth.com>"
(Optionally SMTP_* and FROM_EMAIL if you prefer SMTP)

## Seed
- `firestore.products.seed.json` (Baseline $65, Post Block $199)
- `firestore.timeslots.seed.json` (initial Tuesday/Thursday templates)
